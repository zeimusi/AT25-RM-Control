#include "Aim_Task.h"
void Aim_Task(){
     static portTickType currentTime;		 
	   for(;;){
			currentTime = xTaskGetTickCount();
      if(SystemState == SYSTEM_RUNNING) {
				Send_to_Vision();
	      Aim_Offset();
				AimRef_Update();
				Aim_Shoot();
			}
			vTaskDelayUntil(&currentTime, 1);		 
	   }
}
    
    