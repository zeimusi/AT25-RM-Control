#include "Aim_Task.h"
void Aim_SendDown();
void Aim_Task(){
     static portTickType currentTime;		 
	   for(;;){
			currentTime = xTaskGetTickCount();
      if(SystemState == SYSTEM_RUNNING) {
//				Send_to_Vision();
	        Aim_Calc();
				  
				  Aim_Offset(IMU.Angle_Roll * Pi/180.0,IMU.Angle_Pitch * Pi /180.0,IMU.Angle_Yaw * Pi /180.0);
				
//				AimRef_Update();
				Aim_Shoot();
				Aim_SendDown();
			}
			vTaskDelayUntil(&currentTime, 1);		 
	   }
}
    