#include "Aim.h"
#include "string.h"
#include "Data_Exchange.h"
#include "IMU.h"
#include "usb_task.h"
#include "Gimbal.h"
#include "arm_math.h"

/* �Ӿ� */
extern USBD_HandleTypeDef hUsbDeviceFS;
extern IMU_t IMU;
float DistanceHorizontal(Pose_t pose);
float Predicted_Gap = 0; 
struct Armor
{
    float x;
    float y;
    float z;
    double yaw;
} Armor;


Aim_Rx_info Aim_Rx_infopack;
Aim_Rx_t Aim_Rx = { .Fixed_Center_time = 0, .Fixed_Armor_time = 100, .K = 0.01903f, .Rx_State = TIMESTAMP ,.K_thre = 2.0f/3.0f};
Aim_Tx_t Aim_Tx;
double ballisticSolver(float horizontal, float vertical, double bullet_speed, double k);
float Get_bullet_fly_time( float horizontal, float bullet_speed, float angle_pitch);
float Get_Pitch_Angle_Compensation(float horizontal, float vertical, float bullet_speed, float k);
void transformPointGunLinkToGun(const float pointInGunLink[3],float xOffest, float yOffest, float zOffest, float pointInGun[3]) ;
void transformPointGimbalToGunLink(const float pointInGimbal[3],
    float roll, float pitch, float yaw,
    float pointOutGunLink[3]);
void rotationMatrixFromRPY(float roll, float pitch, float yaw, float R[3][3]);
/* ���Ӿ�������Ϣ */
void Send_to_Vision()
{
////    uint16_t debug = 0;
////    static uint8_t Count = 0, Count_Max = 8; //���Ʒ���Ƶ�ʣ�����IMUƵ�ʸ��ģ����Ӿ����͵�Ƶ�� = IMUƵ��(1k) / Count_Max
////    if(hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED && Aim_Rx.Rx_State == TIMESTAMP)
////        VCOMM_Transmit(0, 10, (uint8_t *)"give_me_time", sizeof("give_me_time"));//Get Vision TimeStamp
////    if(hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED && Aim_Rx.Rx_State == COLOUR && (Referee_data_Rx.robot_color == 1 || !Referee_data_Rx.robot_color))
////        VCOMM_Transmit(2, 10, &Referee_data_Rx.robot_color, sizeof(Referee_data_Rx.robot_color));//Send Color��أ���1��0 �Ӿ���Ҫ��ģ�����0��1
////    if(hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED && ++Count == Count_Max && Aim_Rx.Rx_State != TIMESTAMP && Aim_Rx.Rx_State != COLOUR){
////        Aim_Tx.TimeStamp     = xTaskGetTickCount() +  Aim_Rx.TimeStamp_setoff;
//        Aim_Tx.Quaternions.w=  IMU.q[0];
//        Aim_Tx.Quaternions.x = IMU.q[1];
//        Aim_Tx.Quaternions.y = IMU.q[2];
//        Aim_Tx.Quaternions.z = IMU.q[3];
//        VCOMM_Transmit(1, 10, (uint8_t *)&Aim_Tx, sizeof(Aim_Tx));
////        Count = 0;
////    }
	
//        VCOMM_Transmit(1, 10, (uint8_t *)&SendVision, sizeof(SendVision));
}

void AimRef_Update(){
//	  if(Aim_Data.Flag == 1 && (ReceiveVisionData.data.x  != 0  || ReceiveVisionData.data.y != 0)){
//		 if(RecodeAIM == 0){
//     Aim_Data.Recode_Yaw    = Aim_Rx.Predicted_Center_Yaw;
//	   Aim_Data.Recode_Pitch  = Aim_Rx.Predicted_Center_Pitch;
//		 RecodeAIM ++;
//		 }  
//     Aim_Data.Ref_Yaw    = Aim_Rx.Predicted_Center_Yaw;
//	   Aim_Data.Ref_Pitch  = Aim_Rx.Predicted_Center_Pitch;
//		}
//		 else{
//     Aim_Data.Recode_Yaw    = 0.5 *(Aim_Rx.Predicted_Center_Yaw + Aim_Data.Recode_Yaw);
//	   Aim_Data.Recode_Pitch  = 0.5 *(Aim_Rx.Predicted_Center_Pitch + Aim_Data.Recode_Pitch);
//		 
//		 }

}
float offsat = 0,speed = 0;

/* ������� */
        float yaw ;
        float yaw_v;
        float r;
        float x_v;
        float y_v ;
        float z_v ;
        float r1;
        float r2;
        float dz;
        float temp_pitch;
        float armor_x,armor_y,armor_z;
        static  uint8_t idx = 0;  //����

void Aim_Calc(){
    /* ����ϵͳ���ڲ����� */
    static int16_t Shoot_time_Gap = 0, Shoot_time_cnt = 0;      //������(��������������Ҫ����ҵ���)
    static float Bullet_fly_time = 0 , Bullet_Speed = 0;//��̬Ԥ��ʱ��
    static float Tar_horizontal, Tar_vertical, Tar_angle_pitch;//����ģ��
    static float distance_min = 0;//������װ�װ�
    int use_1 = 1;
    float s_bias = 0 ;         //ǹ��ǰ�Ƶľ���
    float z_bias = 0.20;         //yaw������ǹ��ˮƽ��Ĵ�ֱ����

      /* ����ģʽ */
    if (DeviceState.PC_State == Device_Online){
//        Aim_Rx.Rx_State == UPDATING ? Predicted_Gap = 0 : Predicted_Gap ++;//�������,���Ӿ��մ��ڵ��ȥԤ��
        //Ԥ��ʱ��ms
        Aim_Rx.Predicted_Armor_time  =  (Aim_Rx.Fixed_Armor_time  + Aim_Rx_infopack.delay + Bullet_fly_time + Predicted_Gap) / 1000.0f ;
#if DEBUG_OFFSET
        Aim_Rx.Predicted_Center_time = 0;//Ԥ��ʱ��ms
        Aim_Rx.Predicted_Armor_time  =  0 ;
#endif   
        /* Center_Pose�������ģ�����(Ԥ��) */
        yaw = ReceiveVisionData.data.yaw;
        yaw_v = ReceiveVisionData.data.v_yaw;
        x_v = ReceiveVisionData.data.vx;
        y_v = ReceiveVisionData.data.vy;
        z_v = ReceiveVisionData.data.vz;
        Aim_Rx.Predicted_Center_Pose.x = ReceiveVisionData.data.x;
        Aim_Rx.Predicted_Center_Pose.y = ReceiveVisionData.data.y;
        Aim_Rx.Predicted_Center_Pose.z = ReceiveVisionData.data.z;
        r1 = ReceiveVisionData.data.r1;
        r2 = ReceiveVisionData.data.r2;
        dz = ReceiveVisionData.data.dz;
				/* ��������ϵ�� */
				st.k = Aim_Rx.K; 


        Aim_Rx.Predicted_Center_Pose.HorizontalDistance = DistanceHorizontal(Aim_Rx.Predicted_Center_Pose);
        Aim_Data.HorizontalDistance = DistanceHorizontal(Aim_Rx.Predicted_Center_Pose);
				Aim_Data.id = ReceiveVisionData.data.id;
        Tar_horizontal        = Aim_Rx.Predicted_Center_Pose.HorizontalDistance;
        Tar_vertical          = Aim_Rx.Predicted_Center_Pose.z;
//				Bullet_fly_time = Aim_Rx.Predicted_Center_Pose.HorizontalDistance/23.0 * 1000.0;
        Bullet_Speed = 23;
        Aim_Rx.PitchOffset    = Get_Pitch_Angle_Compensation(Tar_horizontal, Tar_vertical, Bullet_Speed, Aim_Rx.K);  //�������������
        Tar_angle_pitch       = atan2(Tar_vertical,Tar_horizontal);
				/* �������ʱ�� */
        Bullet_fly_time       = Get_bullet_fly_time(Tar_horizontal, Bullet_Speed, Tar_angle_pitch + Aim_Rx.PitchOffset);
//        Bullet_fly_time       = 0.1;
        Aim_Rx.Predicted_Center_time = (Aim_Rx.Fixed_Center_time + Aim_Rx_infopack.delay + Bullet_fly_time + Predicted_Gap + Shoot_time_Gap) / 1000.0f;

        Aim_Rx.Predicted_Center_Pose.x = ReceiveVisionData.data.x + Aim_Rx.Predicted_Center_time * x_v;
        Aim_Rx.Predicted_Center_Pose.y = ReceiveVisionData.data.y + Aim_Rx.Predicted_Center_time * y_v;
        Aim_Rx.Predicted_Center_Pose.z = ReceiveVisionData.data.z + Aim_Rx.Predicted_Center_time * z_v;
        Aim_Rx.Predicted_Center_Yaw = yaw + Aim_Rx.Predicted_Center_time * yaw_v ;
				
//				 //ǰ��վ
//				if(ReceiveVisionData.data.armors_num == ARMOR_NUM_OUTPOST){
//							for (int i = 0; i<3; i++) {
//								float tmp_yaw = Aim_Rx.Predicted_Center_Yaw + i * 2.0 * PI/3.0;  // 2/3PI
//								float r =  (r1 + r2)/2;   //������r1=r2 ����ȡ��ƽ��ֵ
//								Aim_Rx.Predicted_Armor_Pose[i].x = Aim_Rx.Predicted_Center_Pose.x - r*sin(tmp_yaw);
//								Aim_Rx.Predicted_Armor_Pose[i].y = Aim_Rx.Predicted_Center_Pose.y + r*cos(tmp_yaw);
//								Aim_Rx.Predicted_Armor_Pose[i].z = Aim_Rx.Predicted_Center_Pose.z;
//								Aim_Rx.Predicted_Armor_Yaw[i] = tmp_yaw;
//				   	}
//        //TODO ѡ������װ�װ� ѡ���߼������Լ�д�����һ���Ӣ����

//				}
//				else{
					/* �����۲� */
							for (int i = 0; i<4; i++) {
								float tmp_yaw;
//								if(fabsf(ReceiveVisionData.data.v_yaw) < 0.20){
									tmp_yaw = yaw;
//								} else {
//									tmp_yaw = Aim_Rx.Predicted_Center_Yaw + i *  Pi / 2.0; 								
//								}
                float r = use_1 ? r1 : r2;
								Aim_Rx.Predicted_Armor_Pose[i].x = Aim_Rx.Predicted_Center_Pose.x - r*sin(tmp_yaw);
								Aim_Rx.Predicted_Armor_Pose[i].y = Aim_Rx.Predicted_Center_Pose.y + r*cos(tmp_yaw);		

//								if(fabsf(yaw_v) < 0.10){
//								Aim_Rx.Predicted_Armor_Pose[i].x = Aim_Rx.Predicted_Center_Pose.x -r;
//								Aim_Rx.Predicted_Armor_Pose[i].y = Aim_Rx.Predicted_Center_Pose.y + r;
//									
//								}
								Aim_Rx.Predicted_Armor_Pose[i].z = use_1 ? Aim_Rx.Predicted_Center_Pose.z : Aim_Rx.Predicted_Center_Pose.z + dz;
								Aim_Rx.Predicted_Armor_Yaw[i] = tmp_yaw;
								use_1 = !use_1;
//				   	}
	            //2�ֳ������߷�����
            //1.����ǹ�ܵ�Ŀ��װ�װ�yaw��С���Ǹ�װ�װ�
            //2.������������װ�װ�


            //����ǹ�ܵ�Ŀ��װ�װ�yaw��С���Ǹ�װ�װ�
        float yaw_diff_min = fabsf(Aim_Data.Ref_Yaw - Aim_Rx.Predicted_Armor_Yaw[0]);
        for (int i = 1; i<4; i++) {
            float temp_yaw_diff = fabsf(Aim_Data.Ref_Yaw - Aim_Rx.Predicted_Armor_Yaw[i]);
            if (temp_yaw_diff < yaw_diff_min)
            {
                yaw_diff_min = temp_yaw_diff;
                idx = i;
            }
			
				}
				armor_x = Aim_Rx.Predicted_Armor_Pose[idx].x /*+ x_v * Aim_Rx.Predicted_Armor_time*/;
				armor_y = Aim_Rx.Predicted_Armor_Pose[idx].y /*+ y_v * Aim_Rx.Predicted_Armor_time*/;
				armor_z = Aim_Rx.Predicted_Armor_Pose[idx].z /*+ z_v * Aim_Rx.Predicted_Armor_time*/;
//				/* p��ǶȲ��� */
//       temp_pitch = pitchTrajectoryCompensation(sqrt(armor_x * armor_x + armor_y * armor_y) + s_bias,
//            armor_z + z_bias, Bullet_Speed);
////    if(temp_pitch)
////        Aim_Data.Ref_Pitch = - (float)temp_pitch * 180 / PI ;
//        Aim_Data.Ref_Pitch = - (float)atan2(armor_z +z_bias , sqrt(armor_x * armor_x + armor_y * armor_y)) * 180 / PI ;
//    if(armor_x || armor_y)
//        Aim_Data.Ref_Yaw = (float)(atan2(armor_y, armor_x)) * 180 / PI + IMU.r * 360.0f ;//��������

			}
		}else Predicted_Gap = 0;
}
/* ���鲹�� */
    //��gun_link ����ϵ�µĵ�
    float pointGunLink[3] = { 0.0f, 0.0f, 0.0f };
    //��gun����ϵ�µĵ�
    float pointGun[3] = { 0.0f, 0.0f, 0.0f };
    // �����ǵ�ǹ�ڵ�ƫ��
    float xOffest = 0.0f;
    float yOffest = 0.0f;
    float zOffest = 0.2f;

void Aim_Offset(float roll,float pitch,float yaw){
		//�� gimbal ����ϵ�µ�װ�װ����ά�����:
    float pointGimbal[3];
    pointGimbal[0] = armor_x;
	  pointGimbal[1] = armor_y;
	  pointGimbal[2] = armor_z;
    // �����Ƿ����Ӿ���rpy
//    float roll = 0.0f;
//    float pitch = 0.0f;
//    float yaw = 0.5236f;


    
		
    transformPointGimbalToGunLink(pointGimbal, roll, pitch, yaw, pointGunLink);
    transformPointGunLinkToGun(pointGunLink, xOffest, yOffest, zOffest, pointGun);
		
		Aim_Data.Ref_Pitch = -atan2(pointGun[2],pointGun[0]) *180 /Pi +  IMU.Angle_Pitch;
		Aim_Data.Ref_Yaw   =  atan2(pointGun[1],pointGun[0]) * 180 /Pi + IMU.Angle_Yaw;
}
float thersold = 2.0f;
/* ��� */
void Aim_Shoot(){
	Aim_Data.AimShoot = AimStop;
	static float Data,LastData;
	
	Data = Aim_Rx.Predicted_Center_Yaw;
	if(Data == LastData)Aim_Data.Flag = 0;
	int tim = 0;
	 /* ��̬����ֵ */
	if(ReceiveVisionData.data.id == ARMOR_HERO)
			thersold = atan2(AM12_ARMOR_X / 2.0f,Aim_Rx.Predicted_Center_Pose.HorizontalDistance) * 180 / Pi;
	else 	
	thersold = atan2(AM02_ARMOR_X / 2.0f,Aim_Rx.Predicted_Center_Pose.HorizontalDistance) * 180 / Pi;

	if(GimbalCtrl == gAim ){
		 Aim_Data.AimShoot = AimReady;
		 if(
			 ABS(Aim_Data.Ref_Yaw - IMU.Angle_Yawcontinuous) <= thersold &&
			  ReceiveVisionData.data.tracking
		 ){
			  Aim_Data.AimShoot = AimFire;
		 }
	}
	LastData =Data;

}
///* ���⴮��PCͨ�Ž��ջص����� */
//void VCOMM_CallBack(uint8_t fun_code, uint16_t id, uint8_t *data, uint8_t len)
//{
//    static int64_t time = 0;
//    if(id == 1 && fun_code == 0 ){
//        uint64_t StandardTimeStamp;
//        memcpy(&StandardTimeStamp, data, sizeof(StandardTimeStamp));      // ʱ���ͬ��
//        Aim_Rx.TimeStamp_setoff = StandardTimeStamp - xTaskGetTickCount();
////        Aim_Rx.Rx_flag            = 0;
//    }
//    
//    if ( id == 1 && fun_code == 1 ){
//        memcpy(&Aim_Rx_infopack, data, sizeof(Aim_Rx_info));        //��������
////        Aim_Rx.Rx_flag            = 1;
//			  Aim_Data.Flag                    = 1;  
//			  Aim_Rx.Rx_State  = UPDATING;
//        Aim_Tx.Time_Gap = xTaskGetTickCount() - time;
//        time = xTaskGetTickCount();
//    }
//		else {
//		Aim_Data.Flag = 0;
//		}

//    
//    if (id == 2 && fun_code == 1 ){				//�״�����

//		}
//      Feed_Dog(&PC_Dog);
//}


/* ����ӵ�����ʱ�� */
float Get_bullet_fly_time( float horizontal, float bullet_speed, float angle_pitch) {
    float t;
    t = (float)((exp(Aim_Rx.K * horizontal) - 1) / (Aim_Rx.K * bullet_speed * cosf(angle_pitch)));//ˮƽ������÷���ʱ�� t
    if(t < 0){
        //�������س��������̣���������и��������������t��ɸ���
        //����t����ֹ�´ε��û����nan
        t = 0;
        return 0;
    }
    return t;
}


/**
 * ����ά�� pointInGimbal �� gimbal ����ϵ
 * ת���� gun_link ����ϵ��
 *
 * param:
 *  - pointInGimbal: ����װ�װ���ά��(�� gimbal ����ϵ��)
 *  - roll, pitch, yaw: gimbal_link -> gimbal ��ŷ����
 *                      (������ʱ, P_gimbal = R * P_gimbal_link)
 *  - pointOutGimbalLink: ���װ�װ���ά��(�� gun_link ����ϵ��)
 */
float R[3][3];
void transformPointGimbalToGunLink(const float pointInGimbal[3],
    float roll, float pitch, float yaw,
    float pointOutGunLink[3])
{
    // �Ȼ�ȡ������ת���� R (gimbal_link -> gimbal)
    float x,y,z;
    rotationMatrixFromRPY(roll, pitch, yaw, R);

    // ��ΪҪ����(gimbal -> gun_link)��
    //    �Դ���ת��˵������� R_inv = R^T

    // �� R^T * pointInGimbal �õ� pointInGimbalLink
    // R^T = [ R[0][0], R[1][0], R[2][0]
    //         R[0][1], R[1][1], R[2][1]
    //         R[0][2], R[1][2], R[2][2] ]
    x = R[0][0] * pointInGimbal[0] + R[1][0] * pointInGimbal[1] + R[2][0] * pointInGimbal[2];
    y = R[0][1] * pointInGimbal[0] + R[1][1] * pointInGimbal[1] + R[2][1] * pointInGimbal[2];
    z = R[0][2] * pointInGimbal[0] + R[1][2] * pointInGimbal[1] + R[2][2] * pointInGimbal[2];

    pointOutGunLink[0] = x;
    pointOutGunLink[1] = y;
    pointOutGunLink[2] = z;
}
/**
 * ����ŷ����(roll, pitch, yaw)������ת����R (3x3)��
 * ��ת˳��Ϊ Z-Y-X(����-����-��ת)��
 */
float sr,cr,sp,cp,sy,cy;
void rotationMatrixFromRPY(float roll, float pitch, float yaw, float R[3][3])
{
	
    sr = arm_sin_f32(roll);
    cr = arm_cos_f32(roll);
    sp = arm_sin_f32(pitch);
    cp = arm_cos_f32(pitch);
    sy = arm_sin_f32(yaw);
    cy = arm_cos_f32(yaw);

    // Rz(yaw) * Ry(pitch) * Rx(roll)
    R[0][0] = cy * cp;
    R[0][1] = cy * sp * sr - sy * cr;
    R[0][2] = cy * sp * cr + sy * sr;

    R[1][0] = sy * cp;
    R[1][1] = sy * sp * sr + cy * cr;
    R[1][2] = sy * sp * cr - cy * sr;

    R[2][0] = -sp;
    R[2][1] = cp * sr;
    R[2][2] = cp * cr;
}
void transformPointGunLinkToGun(const float pointInGunLink[3],float xOffest, float yOffest, float zOffest, float pointInGun[3]) {
	pointInGun[0] = pointInGunLink[0] + xOffest;
	pointInGun[1] = pointInGunLink[1] + yOffest;
	pointInGun[2] = pointInGunLink[2] + zOffest;
}
		
/* ����㵽ԭ��ˮƽ���� */
float DistanceHorizontal(Pose_t pose){
    return sqrt(  pose.x * pose.x + pose.y * pose.y);
}

/* ����㵽ԭ��ľ��� */
float DistanceToOrigin(Pose_t pose){
    return sqrt(  pose.x * pose.x + pose.y * pose.y + pose.z * pose.z);
}


/* �����������������ģ�� ���÷����ٶ���Pitch����ֱ�߶� */
float monoAirResistance_Model(float horizontal, float bullet_speed, float angle_pitch, float k){
    float actual_vertical, t;
    
    t = Get_bullet_fly_time(horizontal, bullet_speed, angle_pitch);
    actual_vertical = bullet_speed * sin(angle_pitch) * t - GRAVITY * t * t / 2; //�ó��ӵ���򵽵���ֱ�߶�
//    actual_vertical = (1 / k) * log(k * bullet_speed * sin(angle_pitch) * t + 1) - (GRAVITY * t*t)/( ( 1/k ) * (2 * t * bullet_speed * sin(angle_pitch) + 2) ); // ������������ģ��
    return actual_vertical;
}

/* ���Pitch��ǶȲ���(���������������������Զ���룬С�Ƕ�) */
float Get_Pitch_Angle_Compensation(float horizontal, float vertical, float bullet_speed, float k) {
    float temp_vertical, actual_vertical, error_vertical;
    float pitch, pitch_new;
    
    pitch = atan(vertical/ horizontal);
    temp_vertical = vertical;
    //����������
    for (uint8_t i = 0; i < 20; i++){
        pitch_new = atan(temp_vertical/horizontal);
        actual_vertical = monoAirResistance_Model(horizontal, bullet_speed, pitch_new, k);
        error_vertical = 0.3f * (vertical - actual_vertical);
        temp_vertical = temp_vertical + error_vertical;
        if (fabsf(error_vertical) < 0.0001f)
            break;
    }
    return (pitch_new - pitch) * 180 / Pi;
}

void Aim_SendDown(){
	   if(DeviceState.PC_State == Device_Online)
		 Gimbal_action.vision_status = vision_online;
		 else Gimbal_action.vision_status = vision_offline;
		 Gimbal_data.vision_distance = Aim_Data.HorizontalDistance * 100;
	   Gimbal_action.vision_number   = Aim_Data.id;

}